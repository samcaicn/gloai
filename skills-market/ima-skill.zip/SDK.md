# IMA 知识库 SDK 说明

## 概述

IMA 知识库已集成到平台对话流程。客户端只需发送带标记的消息，服务器自动搜索知识库并返回结果。

## 使用方式

### 触发标记

| 标记 | 示例 |
|------|------|
| `#知识库` | `#知识库 跨境电商政策` |
| `#ima` | `#ima AI创业指南` |
| `#搜索知识` | `#搜索知识 产品需求` |

### 调用示例

```
POST /api/v1/supply/{item_id}/chat
{
  "tenant_id": "xxx",
  "client_id": "yyy",
  "message": "#知识库 跨境电商政策"
}
```

### 返回示例

```json
{
  "success": true,
  "ima_knowledge": true,
  "query": "跨境电商政策",
  "results": [
    {
      "media_id": "img_xxx",
      "title": "跨境电商协会联盟.jpg",
      "media_type": 9,
      "_knowledge_base_name": "海南省跨境电子商务协会"
    },
    {
      "media_id": "weburl_xxx",
      "title": "TikTok+Temu+AI 做跨境",
      "media_type": 2
    }
  ],
  "knowledge_bases": [
    {"id": "kb_xxx", "name": "海南省跨境电子商务协会"}
  ],
  "session_id": null
}
```

### media_type 类型

| 值 | 类型 |
|----|------|
| 1 | PDF 文档 |
| 2 | 网页链接 |
| 3 | Word 文档 |
| 6 | 微信文章 |
| 9 | 图片 |
| 11 | IMA 笔记 |

## 正常对话

未带触发标记时，消息正常转发到微信用户：

```json
{
  "success": true,
  "session_id": "abc123",
  "status": "forwarded",
  "forwarded_to_wechat": true
}
```

## 客户端 UI 建议

添加"知识库"图标按钮：
1. 点击后在输入框插入 `#知识库 `
2. 用户输入内容后发送
3. 展示搜索结果列表