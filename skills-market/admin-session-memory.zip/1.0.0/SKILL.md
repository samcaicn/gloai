---
name: "admin-session-memory"
description: "租户 admin ilink 微信会话个性化记忆。Invoke when admin 通过 ilink 发送聊天消息时，自动召回偏好注入 LLM 上下文并记录新消息到三层记忆。"
version: "1.0.0"
author: "平台内置"
category: "admin_runtime"
skill_type: "platform.runtime"
keywords:
  - ilink
  - admin
  - memory
  - personalization
  - stm
  - mtm
  - lpm
  - hermes
required_capabilities:
  - llm_client
  - cos_storage
---

# Admin Session Memory

租户 admin ilink 微信会话个性化记忆技能（系统运行时技能）。

落地设计方案 §2.3.4 租户特征学习 + §2.1 ilink 会话层。复用现有 HermesMemory 三层架构（STM/MTM/LPM）+ MemoryManager 核心记忆，**不引入新存储**。

## 触发条件

| 场景 | 触发方式 |
|------|---------|
| admin 发送 ilink 聊天消息 | `IlinkChatService.chat()` / `chat_stream()` 自动调用 |
| admin 发送 `/command` 指令 | `tenant_admin_commands.handle_admin_command()` 可选接入 |

**不需要客户端调用**——这是平台后端运行时技能，admin 无感知。

## 工作流

### 1. 召回（Recall）— 调 LLM 前

admin 发消息 → `recall_admin_context(tenant_id, query=message)` → 3 路召回（对齐设计方案 §2.3.4）：

| 路 | 数据源 | 用途 |
|----|--------|------|
| 1 | `TenantPreferenceStore.as_injection_prompt` | LPM 租户偏好（语气/格式/语言） |
| 2 | `DeviceClientPreferenceStore.query` | LPM 设备偏好（需 device_fingerprint，ilink 会话通常无） |
| 3 | `MemoryManager.summarize_for_context` | 跨会话核心记忆摘要 |

拼接成 system prompt，注入 LLM messages 头部：

```
[system] 以下是该租户管理员的个性化上下文，请据此调整回复风格：

租户偏好:
- [communication_style] 喜欢简洁回复
- [report_format] 偏好表格
- [language] 中文

近期记忆:
- 2026-06-22 询问了 AINL 引擎状态
- 2026-06-21 调整了任务派发策略
```

### 2. 记录（Record）— 调 LLM 后

LLM 回复完成 → `record_admin_message(tenant_id, role, content, is_admin)`：

1. **核心记忆**：写入 `MemoryManager`（`event_type="admin_chat"`），跨会话可召回
2. **偏好推断**（仅 user 消息）：关键词 + 领域词匹配 → `TenantPreferenceStore.reinforce`
   - **直接落 LPM COS**（绕过 STM 多容器 race）
   - 已存在则 +heat + confidence，不存在则新建直接进 LPM
   - AINL 引擎（`tp.query` = `lpm.query`）能立即召回到

偏好推断正则（收紧，要求接领域词，防误判）：
- "我喜欢/我偏好/我习惯/我希望 + 回复/格式/风格/语气/语言/方式/排版" → `communication_style`（0.8）
- "不要/别/从不/禁止 + 回复/回答/使用/出现/包含/采用" → `communication_style`（0.7）
- "语言:中文" → `language`（0.85）
- "格式:表格" → `report_format`（0.8）
- "质量:高" → `quality_threshold`（0.75）
- "成本/预算:100" → `cost_sensitivity`（0.75）
- "排期/时段:工作日" → `scheduling`（0.75）
- "我是/我擅长:前端" → `domain_expertise`（0.8）

单条消息偏好数上限 5（防 DoS）。

### 3. 三层晋升（自动）

```
STM（会话内 ring buffer, heat=1）
  ↓ reinforce ≥3 次
MTM（会话摘要, 7 天 TTL）
  ↓ heat 达标或显式 promote
LPM（长期偏好, COS 持久化, 180 天衰减）
```

admin 多次表达同一偏好 → heat 累加 → 自动晋升 LPM → 长期影响所有 AINL 流程（不仅 ilink 会话）。

## 与 AINL 引擎的协同

AINL 引擎的 `_recall_hermes_preferences`（`ainl_engine.py:214`）已经做 3 路召回注入 `clarified_context.hermes_prefs`。本技能记录的偏好会**自动被 AINL 引擎复用**：

```
admin 在 ilink 说 "我喜欢简洁回复"
  ↓ record_admin_message
  ↓ TenantPreferenceStore.record (STM, heat=1)
  ↓ 多次强化后晋升 LPM
  ↓
admin 提交 AINL 需求
  ↓ AINLEngine._recall_hermes_preferences
  ↓ TenantPreferenceStore.query → 命中 "喜欢简洁回复"
  ↓ 注入 clarified_context.hermes_prefs
  ↓ DAG 节点 payload 带偏好
  ↓ 客户端执行时按偏好调整输出
```

## 安全约束

- **租户隔离**：所有召回按 `tenant_id` 过滤，`MemoryManager` 强制 `tenant_id` 必传
- **失败降级**：recall/record 任一异常都 `logger.debug` 静默降级，不阻塞 ilink 会话
- **内容截断**：单条消息记录上限 2000 字符（防 COS 写入过大）
- **召回上限**：注入 prompt 上限 800 字符（防 prompt 膨胀）
- **偏好推断保守**：只识别明确关键词，避免误判

## 数据流

```
admin 微信消息
  │
  ▼
ilink_chat.chat() / chat_stream()
  │
  ├─ 3.5 recall_admin_context(tenant_id, query=message)
  │     ├─ TenantPreferenceStore.as_injection_prompt → LPM 偏好
  │     └─ MemoryManager.summarize_for_context → 核心记忆
  │     ↓
  │   build_system_prompt → 注入 messages[0]
  │
  ├─ 4. LLM 调用（带个性化上下文）
  │
  └─ 5.5 record_admin_message(tenant_id, role, content, is_admin)
        ├─ MemoryManager.record → 核心记忆（跨会话）
        └─ _infer_and_record_preferences → TenantPreferenceStore.reinforce
              ↓
            LPM (COS 持久化，直接落，绕过 STM race)
              ↓
            AINL 引擎 tp.query 立即可召回

  └─ 5.6 auto_evaluate_satisfaction(tenant_id, user_msg, assistant_msg)
        ├─ asyncio.create_task(asyncio.to_thread(...))  # 异步 fire-and-forget
        ├─ _detect_sentiment(user_msg) → (emotion, score)  # 计数法
        ├─ neutral → 不上报（防噪声）
        ├─ 节流: 30s 内每租户最多 1 次 auto 上报
        ├─ 显式 feedback 抑制: 60s 内有 /hermes feedback 则跳过
        └─ satisfied/dissatisfied → hermes_evaluator.submit_report(report_only=True)
              ↓
            仅记录报告，不触发 SkillEvolutionEngine（L1 运行时模块保护）
```

## 满意度评价与进化约束

本技能自身注册在 `systemskills/manifest.json`（`system_runtime` category），**不走自动进化**（`auto_update=false`）。满意度数据仅记录用于分析，不驱动 promote/demote/retire。

### 双通道满意度上报

**通道 1：自动评价（隐式，默认开启）**

每轮对话（user + assistant）完成后，`auto_evaluate_satisfaction` 自动从 user 消息情绪推断满意度：

| 情绪 | 关键词示例 | 分数 | 上报 |
|------|-----------|------|------|
| satisfied_strong | 很好/不错/完美/谢谢/解决了/👍/✅ | 0.92 | ✓ |
| satisfied_weak | 可以/还行/差不多/基本满意/大致/凑合 | 0.78 | ✓ |
| dissatisfied_strong | 不对/错误/糟糕/不好/不可以/重新做/❌/👎 | 0.25 | ✓ |
| dissatisfied_weak | 不太对/有点问题/再改改 | 0.45 | ✓ |
| neutral | （无命中或混合情绪） | 0.5 | ✗（防噪声） |

- 满意 → `ExecutionOutcome.SUCCESS`，不满 → `ExecutionOutcome.FAILED`
- 中性不上报（避免噪声污染评分）
- **混合情绪中性**：同时命中满意+不满关键词时按中性处理（防"不对，我是说很好"误判）
- **超长文本截断**：>5000 字符只检测头部 2000 + 尾部 1000（防 DoS）
- `hermes_evaluator.submit_report(report_only=True)`：仅记录报告，**不触发进化引擎**（L1 运行时模块保护）
- **节流**：每租户 30s 内最多 1 次 auto 上报（防高频对话压垮 COS）

**通道 2：显式上报（admin 主动）**

| 命令 | 作用 |
|------|------|
| `/hermes prefs` | 查询本租户偏好记忆（category + confidence + heat） |
| `/hermes feedback <0-1> [comment]` | 显式上报满意度（同样用 `report_only=True`，不触发进化） |

- 显式 feedback 上报后调用 `mark_explicit_feedback(tenant_id)`，**抑制 60s 内的 auto 上报**（防双通道重复计数）

### 进化决策

**本技能是 L1 运行时模块（`system_runtime` category），不走自动进化**：

- `manifest.json` 中 `auto_update=false`（L1 核心运行时走 git 发版）
- auto + 显式 feedback 均用 `submit_report(report_only=True)`，仅记录报告用于分析
- 满意度数据不驱动 `promote` / `demote` / `retire` 决策
- 版本升级通过 git 提交 + manifest.json 手动更新

## 配置

无独立配置。偏好推断关键词模式在 `admin_session_memory.py:_PREF_PATTERNS`，修改后热加载。

## 失败降级

| 场景 | 降级行为 |
|------|---------|
| `recall_admin_context` 异常 | `admin_context=""`，LLM 不带个性化上下文 |
| `record_admin_message` 异常 | 消息不记录，但不影响 LLM 回复 |
| `TenantPreferenceStore` 不可用 | 跳过偏好召回/记录，仅用 MemoryManager |
| `MemoryManager` 不可用 | 跳过核心记忆召回/记录，仅用 TenantPreferenceStore |

## 关键文件

| 文件 | 作用 |
|------|------|
| `server/core/hermes/admin_session_memory.py` | 核心：recall + record + 偏好推断 + 情绪检测 + auto_evaluate |
| `server/core/onboarding/ilink_chat.py` | 注入点：chat() / chat_stream() step 3.5 / 5.5 / 5.6（异步） |
| `server/core/hermes/hermes_evaluation.py` | submit_report(report_only=True) 仅记录不进化 |
| `server/core/ilink/tenant_admin_commands.py` | /hermes feedback + mark_explicit_feedback |
| `server/core/hermes/tenant_preference.py` | LPM 偏好存储（复用） |
| `server/core/memory/memory_manager.py` | 核心记忆（复用） |
| `server/core/hermes/hermes.py` | STM/MTM/LPM 三层架构（复用） |
