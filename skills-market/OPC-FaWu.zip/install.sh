#!/usr/bin/env bash
# OPC-Skills 安装脚本（macOS / Linux / Git Bash）
# 把 skills/ 下所有技能复制到 ~/.claude/skills/
set -e

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SRC="$SCRIPT_DIR/skills"
DEST="${CLAUDE_SKILLS_DIR:-$HOME/.claude/skills}"

if [ ! -d "$SRC" ]; then
  echo "✗ 找不到 skills 目录：$SRC"
  exit 1
fi

mkdir -p "$DEST"
echo "安装 OPC-Skills 到 $DEST"
echo ""

count=0
for d in "$SRC"/*/; do
  [ -d "$d" ] || continue
  name=$(basename "$d")
  rm -rf "$DEST/$name"
  cp -r "$d" "$DEST/$name"
  echo "  ✓ $name"
  count=$((count + 1))
done

echo ""
echo "🎉 已安装 $count 个技能到 $DEST"
echo "重启 Claude Code（或你的 AI Agent）即可生效。"
