# OPC-Skills 安装脚本（Windows PowerShell）
# 把 skills/ 下所有技能复制到 ~/.claude/skills/
$ErrorActionPreference = "Stop"

$Src = Join-Path $PSScriptRoot "skills"
$Dest = if ($env:CLAUDE_SKILLS_DIR) { $env:CLAUDE_SKILLS_DIR } else { Join-Path $env:USERPROFILE ".claude\skills" }

if (-not (Test-Path $Src)) {
  Write-Output "✗ 找不到 skills 目录：$Src"
  exit 1
}

New-Item -ItemType Directory -Force -Path $Dest | Out-Null
Write-Output "安装 OPC-Skills 到 $Dest"
Write-Output ""

$count = 0
Get-ChildItem -Path $Src -Directory | ForEach-Object {
  $target = Join-Path $Dest $_.Name
  if (Test-Path $target) { Remove-Item -Recurse -Force $target }
  Copy-Item -Recurse -Force $_.FullName $target
  Write-Output "  ✓ $($_.Name)"
  $count++
}

Write-Output ""
Write-Output "🎉 已安装 $count 个技能到 $Dest"
Write-Output "重启 Claude Code（或你的 AI Agent）即可生效。"
