# AGENTS.md — 短剧制作技能

## 何时使用

- 用户提到"短剧""短视频剧本""AI 视频""把故事变成视频"
- 用户需要从零开始创作一个可用于 AI 视频生成的工作流
- 用户已有故事点子，需要提炼、扩展为剧本和分镜

## 核心目标

通过 5 轮对话，把原始想法转化为可直接用于 AI 视频工具的创作包：
创意简报 → 核心剧情 → 结构化剧本 → 资产卡 → 分镜表 + 视频 Prompt

## 关键约束

- 每阶段结束必须等用户确认
- 视频 prompt 遵循 Seedance 六段公式
- 成本优先：先用 1.5 Pro 试错，定稿再升级模型
- 一致性：人物外貌锚点 2-3 个，全程不变

## 引用来源

本技能知识来自 kuaiju2c 项目实践：
- videoPromptCrafting
- videoOfficialPromptPatterns
- videoModelSelection
- videoGenerationParams
