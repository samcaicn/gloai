---
name: "skill-discovery"
description: "客户端技能发现与上传闭环。Invoke when 客户端启动时查询可用技能、收到 upload_hint 后上传本地执行良好的技能、或需要刷新技能索引时。"
version: "1.0.0"
author: "平台内置"
category: "client_downloadable"
skill_type: "md"
keywords:
  - skill
  - discovery
  - upload
  - github
  - clawhub
  - sync
required_capabilities:
  - http_client
  - file_read
---

# Skill Discovery

客户端侧技能发现与上传闭环技能。与平台后端 `discovery_promoter` 协同工作。

## 触发条件

| 场景 | 触发方式 |
|------|---------|
| 客户端启动 / 用户浏览技能 | 主动调用 `skill.search` |
| 收到 heartbeat 响应含 `upload_hint.skills` 非空 | 触发上传流程 |
| 用户手动刷新 | 调用 `skill.list` |

## 工作流

### 1. 查询技能（Discovery）

```
POST /api/v2/mcp
Authorization: Bearer <device_token>

{
  "jsonrpc": "2.0",
  "method": "skill.search",
  "params": {
    "query": "<关键词>",
    "source": "external",   // external | system | all
    "limit": 20
  },
  "id": 1
}
```

返回技能列表（含 `skill_id` / `download_url` / `version` / `stars`）。

### 2. 下载技能

客户端拿到 `download_url` 后**直接 HTTP GET 下载**（不走平台中转）。

- GitHub 源：`https://raw.githubusercontent.com/...`
- ClawHub 源：`https://clawhub.com/skills/.../download`
- 平台 COS 源：`cos://...`（需调 `skill.detail` 换预签名 URL）

下载后校验：
- 文件大小 ≤ 100 MiB
- SHA256（若平台返回了 `sha256` 字段）
- 必须包含 `SKILL.md`（frontmatter + body）

### 3. 执行 + 评分上报

客户端执行技能后，调 `hermes.stats` 或直接上报：

```
POST /api/v2/mcp
{
  "jsonrpc": "2.0",
  "method": "hermes.evolve",
  "params": {
    "skill_id": "<执行过的 skill_id>",
    "outcome": "success|partial|failure",
    "quality_score": 0.0-1.0,
    "efficiency": 0.0-1.0,
    "user_feedback": 0.0-1.0
  },
  "id": 2
}
```

平台 Hermes 引擎会累积评分（5 维度加权），样本量 ≥5 后触发自动进化决策。

### 4. 接收 upload_hint

每次 `client.heartbeat` 响应可能含：

```json
{
  "status": "ok",
  "upload_hint": {
    "skills": [
      {"skill_id": "gh:owner-repo-name", "version": "1.0.0", "score": 0.92}
    ],
    "reason": "high_score_eligible_for_upload"
  }
}
```

**含义**：平台检测到本设备执行过这些技能且评分 ≥ 0.8，建议继续执行并上报评分。平台 `discovery_promoter` 会基于累积评分自动决定是否 promote 到 `systemskills/`。

### 5. 评分驱动 promote（替代主动上传）

**注意**：本技能不提供 `skill.upload` action。上传闭环改为**纯评分驱动**：

- 客户端持续执行技能 + 上报 `hermes.evolve` 评分
- 平台 `discovery_promoter` 每日扫描外部技能评分
- 评分达标（overall ≥ 0.85 + success_rate ≥ 0.70 + samples ≥ 5 + 连续 2 次）→ 自动 promote 到 `systemskills/manifest.json`
- 客户端下次 `skill.list` 即可发现新系统技能

**优势**：
- 客户端无需打包上传，降低复杂度
- 平台基于真实执行数据决策，避免恶意上传
- 评分数据已含租户隔离，无跨租户泄露

## 自动升级

本技能自身（`skill-discovery`）也注册在 `systemskills/manifest.json`，受 Hermes 进化闭环约束：
- 客户端执行后上报评分
- 评分 ≥ 0.85 + 样本 ≥5 → promote（minor 版本+1）
- 评分 < 0.5 + 成功率 < 20% → retire

## 安全约束

- **SSRF 防护**：客户端只下载平台返回的 `download_url`，不自行解析任意 URL
- **鉴权**：所有 MCP 调用必须带 `device_token`
- **内容校验**：上传前客户端必须本地校验 SKILL.md frontmatter 完整性
- **配额**：单设备每日上传 ≤ 10 个技能（平台侧限流）

## 失败降级

| 场景 | 降级行为 |
|------|---------|
| `skill.search` 超时 | 显示本地缓存技能 |
| `download_url` 下载失败 | 重试 3 次，仍失败则跳过 |
| `hermes.evolve` 上报失败 | 本地缓存报告，下次 heartbeat 重传 |
| `upload_hint` 为空 | 不触发上传，正常使用 |

## 与平台后端协同

```
客户端                          平台后端
  │                               │
  ├─ client.heartbeat ────────────►
  │                               │ (计算 upload_hint，本租户 reports)
  ◄── upload_hint ────────────────┤
  │                               │
  ├─ skill.search ────────────────►
  ◄── skills[] ───────────────────┤
  │                               │
  ├─ HTTP GET download_url ────► (GitHub/ClawHub/COS)
  │                               │
  ├─ 本地执行 ──┐                  │
  │            └─ hermes.evolve ──►
  │                               │ (累积评分，租户隔离)
  │                               │ (sample≥5 + score≥0.85 + 连续2次)
  │                               │   ↓
  │                               │ discovery_promoter (每日扫描)
  │                               │   ↓
  │                               │ systemskills/manifest.json (CAS 写)
  │                               │
  └─ 下次 skill.list 发现新系统技能 ◄
```
